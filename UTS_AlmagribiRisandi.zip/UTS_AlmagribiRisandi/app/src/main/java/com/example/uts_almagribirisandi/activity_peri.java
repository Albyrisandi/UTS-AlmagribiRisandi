package com.example.uts_almagribirisandi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class activity_peri extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_peri);
    }
}